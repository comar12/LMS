# Axon — Student Portal

A next-generation learning ecosystem (Student Portal). Built from scratch — not derived from any template or competitor.

![Stack](https://img.shields.io/badge/Next.js-14-black) ![TypeScript](https://img.shields.io/badge/TypeScript-5-blue) ![Tailwind](https://img.shields.io/badge/Tailwind-3-38bdf8) ![License](https://img.shields.io/badge/license-MIT-green)

## Tech stack

Next.js 14 (App Router) · TypeScript · Tailwind CSS · Framer Motion · lucide-react · next-themes

## Quick start

```bash
git clone https://github.com/<your-username>/axon-student-portal.git
cd axon-student-portal
npm install
npm run dev          # http://localhost:3000
```

## Deploy to Vercel

1. Push this repo to GitHub (see below).
2. Go to [vercel.com/new](https://vercel.com/new), import the repo.
3. Framework preset auto-detects **Next.js** — no config needed. Click **Deploy**.

Fonts load from Google Fonts via `next/font` and are CDN-optimized automatically on Vercel.

## Pages

| Route | Screen | Status |
|-------|--------|--------|
| `/` | Dashboard — stat tiles, continue-learning hero, **Knowledge Constellation** skill map, study activity, this week, active courses | ✅ Built |
| `/rewards` | Gamification — level hero, XP breakdown, active challenges, level path ladder | ✅ Built |
| `/community` | Community — post composer, activity feed, cohort leaderboard, groups | ✅ Built |
| `/achievements` | Achievements — earned + in-progress badges with rarity tiers | ✅ Built |
| `/courses` · `/assignments` · `/explore` · `/career` | In nav, not yet built | ⏳ Planned |

## Design system

- **Identity:** deep-space dark default; teal "current" + coral "spark" + gold accents
- **Type:** Sora (display) · Inter (body) · JetBrains Mono (data)
- **Tokens:** HSL CSS variables in `src/app/globals.css`, full light + dark sets
- **Signature element:** the Knowledge Constellation — language skills as connected nodes sized by mastery
- **Quality floor:** visible keyboard focus, reduced-motion support, responsive to mobile

## Data

All seed data is in `src/data/` (`student`, `curriculum`, `community`, `gamification`) as typed objects. Swap these for a real API later — components read from the typed shapes, so wiring a backend is a drop-in.

This is a frontend demo: likes/posts use in-session React state, the leaderboard is static, and challenge progress is illustrative. None of it persists yet.

## Fonts: online vs. offline builds

The committed setup uses **Google Fonts** (`src/app/layout.tsx`), which is correct for Vercel and any machine with network access at build time.

If you ever need to build fully offline (no network), a self-hosted fallback is included:

```bash
# switch to offline fonts
mv src/app/layout.tsx src/app/layout.online.tsx.bak
mv src/app/layout.offline.tsx.bak src/app/layout.tsx
# then uncomment the @fontsource imports at the top of src/app/globals.css
```

The `@fontsource/*` packages are already in `package.json` for this case.

## License

MIT — see [LICENSE](./LICENSE).
