export const student = {
  name: 'Layla Hassan',
  firstName: 'Layla',
  level: 'B2 — Upper Intermediate',
  streak: 24,
  xp: 8420,
  nextLevelXp: 10000,
  rank: 7,
  cohortSize: 142,
  avatar: 'LH',
  joinedDays: 96,
}

export type Course = {
  id: string
  title: string
  track: string
  instructor: string
  progress: number
  totalLessons: number
  completedLessons: number
  nextLesson: string
  nextLessonId: string
  color: 'teal' | 'coral' | 'gold' | 'violet'
  cover: string
  hoursLeft: number
}

export const courses: Course[] = [
  {
    id: 'business-english',
    title: 'Business English Mastery',
    track: 'Career Track',
    instructor: 'Sarah Mitchell',
    progress: 68,
    totalLessons: 42,
    completedLessons: 29,
    nextLesson: 'Negotiation Language & Tactics',
    nextLessonId: 'l-neg-01',
    color: 'teal',
    cover: 'from-teal/30 to-teal/5',
    hoursLeft: 6,
  },
  {
    id: 'ielts-prep',
    title: 'IELTS Academic 7.5+',
    track: 'Exam Prep',
    instructor: 'David Okonkwo',
    progress: 41,
    totalLessons: 56,
    completedLessons: 23,
    nextLesson: 'Writing Task 2 — Argument Essays',
    nextLessonId: 'l-w2-04',
    color: 'coral',
    cover: 'from-coral/30 to-coral/5',
    hoursLeft: 14,
  },
  {
    id: 'pronunciation',
    title: 'Accent & Pronunciation Lab',
    track: 'Fluency',
    instructor: 'Emma Clarke',
    progress: 85,
    totalLessons: 30,
    completedLessons: 25,
    nextLesson: 'Connected Speech & Linking',
    nextLessonId: 'l-cs-02',
    color: 'gold',
    cover: 'from-gold/30 to-gold/5',
    hoursLeft: 3,
  },
  {
    id: 'grammar-advanced',
    title: 'Advanced Grammar in Use',
    track: 'Foundations',
    instructor: 'Sarah Mitchell',
    progress: 100,
    totalLessons: 38,
    completedLessons: 38,
    nextLesson: 'Course Complete',
    nextLessonId: '',
    color: 'violet',
    cover: 'from-violet/30 to-violet/5',
    hoursLeft: 0,
  },
]

export const upcoming = [
  { id: 'u1', type: 'live', title: 'Speaking Workshop: Job Interviews', course: 'Business English', date: new Date(Date.now() + 86400000).toISOString(), time: '6:00 PM', instructor: 'Sarah Mitchell', mins: 60 },
  { id: 'u2', type: 'deadline', title: 'Writing Task 2 — Submission', course: 'IELTS Academic', date: new Date(Date.now() + 2 * 86400000).toISOString(), time: '11:59 PM', instructor: 'David Okonkwo', mins: 0 },
  { id: 'u3', type: 'live', title: 'Pronunciation Clinic (Group)', course: 'Accent Lab', date: new Date(Date.now() + 3 * 86400000).toISOString(), time: '5:30 PM', instructor: 'Emma Clarke', mins: 45 },
  { id: 'u4', type: 'exam', title: 'Mock IELTS — Full Test', course: 'IELTS Academic', date: new Date(Date.now() + 5 * 86400000).toISOString(), time: '10:00 AM', instructor: 'David Okonkwo', mins: 165 },
]

export const assignments = [
  { id: 'a1', title: 'Negotiation Role-Play (Recorded)', course: 'Business English', status: 'in-progress', due: new Date(Date.now() + 86400000).toISOString(), points: 100 },
  { id: 'a2', title: 'Argument Essay — Technology', course: 'IELTS Academic', status: 'not-started', due: new Date(Date.now() + 2 * 86400000).toISOString(), points: 100 },
  { id: 'a3', title: 'Minimal Pairs Drill Set 4', course: 'Accent Lab', status: 'submitted', due: new Date(Date.now() - 86400000).toISOString(), points: 50, grade: 47 },
  { id: 'a4', title: 'Conditionals Mastery Quiz', course: 'Advanced Grammar', status: 'graded', due: new Date(Date.now() - 4 * 86400000).toISOString(), points: 100, grade: 94 },
]

export const skills = [
  { name: 'Speaking', value: 78, tone: 'teal' as const },
  { name: 'Writing', value: 64, tone: 'coral' as const },
  { name: 'Listening', value: 88, tone: 'gold' as const },
  { name: 'Reading', value: 82, tone: 'teal' as const },
  { name: 'Grammar', value: 91, tone: 'violet' as const },
  { name: 'Vocabulary', value: 73, tone: 'coral' as const },
]

export const achievements = [
  { id: 'ac1', name: '24-Day Streak', desc: 'Studied every day for 24 days', icon: 'flame', earned: true, tone: 'coral' },
  { id: 'ac2', name: 'Grammar Master', desc: 'Completed Advanced Grammar with 90%+', icon: 'crown', earned: true, tone: 'gold' },
  { id: 'ac3', name: 'Top 10 Cohort', desc: 'Ranked in top 10 of your cohort', icon: 'trophy', earned: true, tone: 'teal' },
  { id: 'ac4', name: 'Early Bird', desc: 'Complete 10 lessons before 9 AM', icon: 'sunrise', earned: true, tone: 'gold' },
  { id: 'ac5', name: 'Wordsmith', desc: 'Learn 1,000 new vocabulary words', icon: 'book', earned: false, tone: 'violet', progress: 73 },
  { id: 'ac6', name: 'Fluent Speaker', desc: 'Score 85+ on 5 speaking assessments', icon: 'mic', earned: false, tone: 'teal', progress: 60 },
]

export const weeklyActivity = [
  { day: 'Mon', mins: 45 }, { day: 'Tue', mins: 62 }, { day: 'Wed', mins: 30 },
  { day: 'Thu', mins: 78 }, { day: 'Fri', mins: 52 }, { day: 'Sat', mins: 90 }, { day: 'Sun', mins: 40 },
]
