export const leaderboard = [
  { rank: 1, name: 'Yusuf Adeyemi', avatar: 'YA', xp: 12840, streak: 61, you: false, change: 0 },
  { rank: 2, name: 'Chen Wei', avatar: 'CW', xp: 11920, streak: 45, you: false, change: 1 },
  { rank: 3, name: 'Fatima Noor', avatar: 'FN', xp: 11340, streak: 38, you: false, change: -1 },
  { rank: 4, name: 'Diego Ramos', avatar: 'DR', xp: 10610, streak: 52, you: false, change: 2 },
  { rank: 5, name: 'Aisha Bello', avatar: 'AB', xp: 9870, streak: 29, you: false, change: 0 },
  { rank: 6, name: 'Marco Rossi', avatar: 'MR', xp: 8990, streak: 19, you: false, change: -2 },
  { rank: 7, name: 'Layla Hassan', avatar: 'LH', xp: 8420, streak: 24, you: true, change: 3 },
  { rank: 8, name: 'Sofia Costa', avatar: 'SC', xp: 8210, streak: 22, you: false, change: -1 },
  { rank: 9, name: 'Omar Farouk', avatar: 'OF', xp: 7650, streak: 14, you: false, change: 0 },
  { rank: 10, name: 'Priya Patel', avatar: 'PP', xp: 7400, streak: 31, you: false, change: 1 },
]

export const groups = [
  { id: 'g1', name: 'IELTS Warriors', members: 1284, desc: 'Daily practice, mock tests, and band-score strategies.', tone: 'coral', active: true, posts: 42 },
  { id: 'g2', name: 'Business English Pros', members: 876, desc: 'For learners using English at work — meetings, emails, negotiation.', tone: 'teal', active: true, posts: 28 },
  { id: 'g3', name: 'Pronunciation Lab', members: 543, desc: 'Share recordings, get feedback, master tricky sounds together.', tone: 'gold', active: false, posts: 15 },
  { id: 'g4', name: 'Conversation Exchange', members: 2103, desc: 'Find a speaking partner at your level. Practice live.', tone: 'violet', active: true, posts: 67 },
]

export const feed = [
  { id: 'f1', author: 'David Okonkwo', avatar: 'DO', role: 'Instructor', time: '32m ago', group: 'IELTS Warriors', text: 'New mock test drops Friday. This one mirrors the real exam timing exactly — block 2h 45m and treat it like the real thing. Who is in?', likes: 47, comments: 12, liked: true, tone: 'coral' },
  { id: 'f2', author: 'Aisha Bello', avatar: 'AB', role: 'Student', time: '1h ago', group: 'Business English Pros', text: 'Just used the LBR method from the Q&A lesson in a real client call. Bridged a tough question perfectly and closed the deal. This stuff works in the real world!', likes: 89, comments: 23, liked: false, tone: 'teal' },
  { id: 'f3', author: 'Emma Clarke', avatar: 'EC', role: 'Instructor', time: '3h ago', group: 'Pronunciation Lab', text: 'Reminder: connected speech is what makes you sound natural. "What are you doing" becomes "whaddaya doing". Drop your recordings below and I will give feedback this week.', likes: 56, comments: 18, liked: true, tone: 'gold' },
  { id: 'f4', author: 'Diego Ramos', avatar: 'DR', role: 'Student', time: '5h ago', group: 'Conversation Exchange', text: 'Looking for a B2+ speaking partner for 30 min/day, evenings GMT+2. I can help with Spanish in exchange. DM me!', likes: 34, comments: 9, liked: false, tone: 'violet' },
]

export const challenges = [
  { id: 'c1', title: 'Weekend Sprint', desc: 'Complete 5 lessons this weekend', reward: 250, progress: 3, total: 5, ends: '2 days', tone: 'teal' },
  { id: 'c2', title: 'Speaking Streak', desc: 'Record 3 speaking tasks this week', reward: 150, progress: 1, total: 3, ends: '4 days', tone: 'coral' },
  { id: 'c3', title: 'Vocabulary Hunter', desc: 'Learn 50 new words', reward: 300, progress: 38, total: 50, ends: '6 days', tone: 'gold' },
]
