export const levels = [
  { level: 1, name: 'Novice', xp: 0, tone: 'neutral' },
  { level: 2, name: 'Apprentice', xp: 1000, tone: 'neutral' },
  { level: 3, name: 'Communicator', xp: 2500, tone: 'teal' },
  { level: 4, name: 'Conversationalist', xp: 4500, tone: 'teal' },
  { level: 5, name: 'Fluent Speaker', xp: 7000, tone: 'gold' },
  { level: 6, name: 'Eloquent', xp: 10000, tone: 'gold' },
  { level: 7, name: 'Master', xp: 14000, tone: 'coral' },
]

export const currentLevel = 5
export const xpHistory = [
  { label: 'Lessons completed', xp: 4350, tone: 'teal' },
  { label: 'Quizzes & assessments', xp: 2180, tone: 'gold' },
  { label: 'Speaking tasks', xp: 980, tone: 'coral' },
  { labels: 'Streak bonuses', label: 'Streak bonuses', xp: 720, tone: 'violet' },
  { label: 'Community contributions', xp: 190, tone: 'teal' },
]

export const allBadges = [
  { id: 'b1', name: '24-Day Streak', desc: 'Studied every day for 24 days straight', icon: 'flame', earned: true, tone: 'coral', rarity: 'Rare', date: 'Earned 2 days ago' },
  { id: 'b2', name: 'Grammar Master', desc: 'Completed Advanced Grammar with 90%+ average', icon: 'crown', earned: true, tone: 'gold', rarity: 'Epic', date: 'Earned 1 week ago' },
  { id: 'b3', name: 'Top 10 Cohort', desc: 'Reached the top 10 of your cohort leaderboard', icon: 'trophy', earned: true, tone: 'teal', rarity: 'Rare', date: 'Earned 3 days ago' },
  { id: 'b4', name: 'Early Bird', desc: 'Completed 10 lessons before 9 AM', icon: 'sunrise', earned: true, tone: 'gold', rarity: 'Common', date: 'Earned 2 weeks ago' },
  { id: 'b5', name: 'Perfect Week', desc: 'Hit your daily goal every day for a week', icon: 'calendar-check', earned: true, tone: 'teal', rarity: 'Common', date: 'Earned 5 days ago' },
  { id: 'b6', name: 'Quiz Champion', desc: 'Scored 100% on 5 quizzes', icon: 'target', earned: true, tone: 'violet', rarity: 'Rare', date: 'Earned 1 week ago' },
  { id: 'b7', name: 'Wordsmith', desc: 'Learn 1,000 new vocabulary words', icon: 'book-open', earned: false, tone: 'violet', rarity: 'Epic', progress: 73 },
  { id: 'b8', name: 'Fluent Speaker', desc: 'Score 85+ on 5 speaking assessments', icon: 'mic', earned: false, tone: 'teal', rarity: 'Epic', progress: 60 },
  { id: 'b9', name: 'Marathon', desc: 'Reach a 50-day study streak', icon: 'flame', earned: false, tone: 'coral', rarity: 'Legendary', progress: 48 },
  { id: 'b10', name: 'Helping Hand', desc: 'Get 100 likes on community posts', icon: 'heart', earned: false, tone: 'rose', rarity: 'Rare', progress: 34 },
  { id: 'b11', name: 'Course Crusher', desc: 'Complete 5 full courses', icon: 'graduation-cap', earned: false, tone: 'gold', rarity: 'Epic', progress: 20 },
  { id: 'b12', name: 'Night Owl', desc: 'Complete 20 lessons after 10 PM', icon: 'moon', earned: false, tone: 'violet', rarity: 'Common', progress: 45 },
]
