# Pushing Axon to GitHub

This folder is already a git repository with a clean commit history and a
`.gitignore` that excludes `node_modules` and build output. You do **not**
need to run `git init` — just connect it to GitHub and push.

## 1. Create an empty repo on GitHub
Go to https://github.com/new
- Name: `axon-student-portal` (or anything you like)
- **Do not** add a README, .gitignore, or license (this repo already has them)
- Click **Create repository**

## 2. Connect and push
Copy the repo URL GitHub shows you, then run these from inside this folder:

```bash
git remote add origin https://github.com/<your-username>/axon-student-portal.git
git branch -M main
git push -u origin main
```

If GitHub asks for a password, use a **Personal Access Token** (Settings →
Developer settings → Personal access tokens), not your account password.

## 3. (Optional) Deploy
- Go to https://vercel.com/new
- Import the repo you just pushed
- It auto-detects Next.js — click **Deploy**. Live in ~1 minute.

## Notes
- The committed `src/app/layout.tsx` uses Google Fonts — correct for Vercel.
- `npm install` is required after cloning (node_modules is intentionally not committed).
- See `README.md` for the offline-font fallback if you ever build without network.
